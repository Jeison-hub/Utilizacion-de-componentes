﻿namespace aplicacion_con_utilización_de_componentes
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.webBrowser1 = new System.Windows.Forms.WebBrowser();
            this.btnpdf = new System.Windows.Forms.Button();
            this.btnwmp = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // webBrowser1
            // 
            this.webBrowser1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.webBrowser1.Location = new System.Drawing.Point(0, 0);
            this.webBrowser1.MinimumSize = new System.Drawing.Size(20, 20);
            this.webBrowser1.Name = "webBrowser1";
            this.webBrowser1.Size = new System.Drawing.Size(1255, 570);
            this.webBrowser1.TabIndex = 0;
            this.webBrowser1.Url = new System.Uri("http://www.Google.com", System.UriKind.Absolute);
            // 
            // btnpdf
            // 
            this.btnpdf.Location = new System.Drawing.Point(886, 496);
            this.btnpdf.Name = "btnpdf";
            this.btnpdf.Size = new System.Drawing.Size(145, 29);
            this.btnpdf.TabIndex = 1;
            this.btnpdf.Text = "Ir a PDF";
            this.btnpdf.UseVisualStyleBackColor = true;
            this.btnpdf.Click += new System.EventHandler(this.btnpdf_Click);
            // 
            // btnwmp
            // 
            this.btnwmp.Location = new System.Drawing.Point(1096, 496);
            this.btnwmp.Name = "btnwmp";
            this.btnwmp.Size = new System.Drawing.Size(111, 29);
            this.btnwmp.TabIndex = 2;
            this.btnwmp.Text = "Ir a WMP";
            this.btnwmp.UseVisualStyleBackColor = true;
            this.btnwmp.Click += new System.EventHandler(this.btnwmp_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1255, 570);
            this.Controls.Add(this.btnwmp);
            this.Controls.Add(this.btnpdf);
            this.Controls.Add(this.webBrowser1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.WebBrowser webBrowser1;
        private System.Windows.Forms.Button btnpdf;
        private System.Windows.Forms.Button btnwmp;
    }
}

