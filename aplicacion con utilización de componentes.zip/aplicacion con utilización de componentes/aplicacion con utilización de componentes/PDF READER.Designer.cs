﻿namespace aplicacion_con_utilización_de_componentes
{
    partial class PDF_READER
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PDF_READER));
            this.axAcroPDF1 = new AxAcroPDFLib.AxAcroPDF();
            this.btnwmp = new System.Windows.Forms.Button();
            this.btnweb = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.axAcroPDF1)).BeginInit();
            this.SuspendLayout();
            // 
            // axAcroPDF1
            // 
            this.axAcroPDF1.Enabled = true;
            this.axAcroPDF1.Location = new System.Drawing.Point(2, 0);
            this.axAcroPDF1.Name = "axAcroPDF1";
            this.axAcroPDF1.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axAcroPDF1.OcxState")));
            this.axAcroPDF1.Size = new System.Drawing.Size(671, 568);
            this.axAcroPDF1.TabIndex = 0;
            this.axAcroPDF1.Enter += new System.EventHandler(this.axAcroPDF1_Enter);
            // 
            // btnwmp
            // 
            this.btnwmp.Location = new System.Drawing.Point(689, 162);
            this.btnwmp.Name = "btnwmp";
            this.btnwmp.Size = new System.Drawing.Size(90, 67);
            this.btnwmp.TabIndex = 1;
            this.btnwmp.Text = "IR A WMP";
            this.btnwmp.UseVisualStyleBackColor = true;
            this.btnwmp.Click += new System.EventHandler(this.btnwmp_Click);
            // 
            // btnweb
            // 
            this.btnweb.Location = new System.Drawing.Point(679, 276);
            this.btnweb.Name = "btnweb";
            this.btnweb.Size = new System.Drawing.Size(109, 59);
            this.btnweb.TabIndex = 2;
            this.btnweb.Text = "IR A NAVEGADOR";
            this.btnweb.UseVisualStyleBackColor = true;
            this.btnweb.Click += new System.EventHandler(this.btnweb_Click);
            // 
            // PDF_READER
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 580);
            this.Controls.Add(this.btnweb);
            this.Controls.Add(this.btnwmp);
            this.Controls.Add(this.axAcroPDF1);
            this.Name = "PDF_READER";
            this.Text = "PDF_READER";
            ((System.ComponentModel.ISupportInitialize)(this.axAcroPDF1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private AxAcroPDFLib.AxAcroPDF axAcroPDF1;
        private System.Windows.Forms.Button btnwmp;
        private System.Windows.Forms.Button btnweb;
    }
}