﻿using AxWMPLib;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace aplicacion_con_utilización_de_componentes
{
    public partial class PDF_READER : Form
    {
        public PDF_READER()
        {
            InitializeComponent();
        }
        string rutaPDF;
        private void btnwmp_Click(object sender, EventArgs e)
        {
            wmp wmp1 = new wmp();
            wmp1.Show();
            this.Hide();

         
        }

        private void btnweb_Click(object sender, EventArgs e)
        {
            Form1 navegador = new Form1();
            navegador.Show();
            this.Hide();
        }

        private void axAcroPDF1_Enter(object sender, EventArgs e)
        {
            
            rutaPDF = @"C:\utilización de componentes\aplicacion con utilización de componentes\La República Autor Platón.pdf";

            
            if (System.IO.File.Exists(rutaPDF))
            {
                
                axAcroPDF1.LoadFile(rutaPDF);

              
                axAcroPDF1.setView("Fit");

                
                
            }
            else
            {
                MessageBox.Show("El archivo PDF no se encuentra en la ruta especificada.");
            }
        }
    }
}
