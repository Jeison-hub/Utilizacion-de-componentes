﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace aplicacion_con_utilización_de_componentes
{
    public partial class wmp : Form
    {
        public wmp()
        {
            InitializeComponent();
        }
        string rutaVideo;
        private void button2_Click(object sender, EventArgs e)
        {
            PDF_READER PDF1 = new PDF_READER();
            PDF1.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 navegador = new Form1();
            navegador.Show();
            this.Hide();
        }

        private void axWindowsMediaPlayer1_Enter(object sender, EventArgs e)
        {
            
             rutaVideo = @"C:\utilización de componentes\aplicacion con utilización de componentes\PEPPA LA CERDITA - INTRO (ESPAÑOL LATINO DISCOVERY KIDS).mp4";

           
            if (System.IO.File.Exists(rutaVideo))
            {
                
                axWindowsMediaPlayer1.URL = rutaVideo;

                
                axWindowsMediaPlayer1.Ctlcontrols.play();
            }
            else
            {
                MessageBox.Show("El archivo de video no se encuentra en la ruta especificada.");
            }
        }
    }
}
