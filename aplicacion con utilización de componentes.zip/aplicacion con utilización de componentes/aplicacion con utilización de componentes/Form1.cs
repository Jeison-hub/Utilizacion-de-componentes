﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace aplicacion_con_utilización_de_componentes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnpdf_Click(object sender, EventArgs e)
        {
            PDF_READER PDF1 = new PDF_READER();
            PDF1.Show();
            this.Hide();
        }

        private void btnwmp_Click(object sender, EventArgs e)
        {
            wmp wmp1 = new wmp();
            wmp1.Show();
            this.Hide();
        }
    }
}
